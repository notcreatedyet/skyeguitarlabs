/**
 * 
 */
/**
 * @author ethan2
 *
 */
module SkyeGuitar {
	requires java.desktop;
}